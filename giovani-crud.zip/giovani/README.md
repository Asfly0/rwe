# CRUD de Produtos — React + Node/Express (pronto para Supabase)

Frontend em **React**, backend em **Node + Express**. O banco é uma peça
trocável: hoje roda em memória (sem instalar nada), e vira **Supabase**
mudando uma linha do `.env`.

```
giovani/
├─ backend/                     Node + Express
│  ├─ src/
│  │  ├─ server.js              sobe o servidor
│  │  ├─ app.js                 middlewares + rotas
│  │  ├─ config/env.js          único lugar que lê process.env
│  │  ├─ data/
│  │  │  ├─ index.js            escolhe o driver (memory | supabase)
│  │  │  ├─ memory.repository.js
│  │  │  └─ supabase.repository.js
│  │  ├─ controllers/products.controller.js
│  │  ├─ routes/products.routes.js
│  │  ├─ validators/product.validator.js
│  │  └─ middlewares/errorHandler.js
│  └─ supabase/schema.sql       tabela + índices + trigger + RLS
└─ frontend/                    React + Vite
   └─ src/
      ├─ App.jsx
      ├─ api/client.js          único lugar que faz fetch
      ├─ hooks/useProducts.js   estado do CRUD
      └─ components/            ProductForm, ProductTable, Pagination
```

## Rodar

Dois terminais.

```bash
# 1) backend
cd backend
cp .env.example .env
npm install
npm run dev          # http://localhost:3001/api

# 2) frontend
cd frontend
npm install
npm run dev          # http://localhost:5173
```

Não precisa configurar nada para o primeiro teste: o `.env.example` já vem
com `DB_DRIVER=memory` e dois produtos de exemplo.

## Trocar para o Supabase

1. No painel do Supabase: **SQL Editor** → cole `backend/supabase/schema.sql` → **Run**.
2. **Project Settings → API**: copie a `URL` e a chave `service_role`.
3. No `backend/.env`:

```env
DB_DRIVER=supabase
SUPABASE_URL=https://xxxxxxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOi...
SUPABASE_TABLE=products
```

4. Reinicie o backend. `GET /api/health` responde qual driver está ativo.

Nenhum arquivo do frontend, dos controllers, das rotas ou dos validators
muda. Só o driver.

> A chave `service_role` ignora o RLS e **só pode existir no backend**.
> Nunca coloque ela no React — lá ela fica visível no bundle.

## Outro banco (Postgres puro, MySQL, Mongo...)

Se no fim não for Supabase, crie `backend/src/data/<nome>.repository.js`
com os mesmos cinco métodos e registre no mapa de `data/index.js`:

```js
list({ page, limit, search })  // → { items, total }
findById(id)                   // → registro | null
create(data)                   // → registro
update(id, data)               // → registro | null
remove(id)                     // → boolean
```

O resto da aplicação continua igual.

## Endpoints

| Método | Rota                | Ação                                      |
| ------ | ------------------- | ----------------------------------------- |
| GET    | `/api/health`       | status + driver de dados ativo            |
| GET    | `/api/products`     | lista (`?page=1&limit=10&search=texto`)   |
| GET    | `/api/products/:id` | busca um                                  |
| POST   | `/api/products`     | cria                                      |
| PUT    | `/api/products/:id` | atualiza (`PATCH` aceita campos parciais) |
| DELETE | `/api/products/:id` | remove                                    |

Formato das respostas:

```jsonc
// GET /api/products
{ "data": [ /* ... */ ], "meta": { "page": 1, "limit": 10, "total": 2, "totalPages": 1 } }

// POST com dados inválidos → 422
{ "error": "Dados invalidos.", "details": { "price": "Informe um preco numerico maior ou igual a zero." } }
```

O `details` é o que o formulário React usa para mostrar o erro embaixo de
cada campo — a mensagem é escrita uma única vez, no backend.
