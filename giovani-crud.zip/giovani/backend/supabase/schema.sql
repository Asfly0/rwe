-- Cole este arquivo no SQL Editor do Supabase e execute.
-- Depois: no backend, troque DB_DRIVER=memory por DB_DRIVER=supabase.

create extension if not exists "pgcrypto";

create table if not exists public.products (
  id          uuid primary key default gen_random_uuid(),
  name        text        not null check (char_length(trim(name)) between 2 and 120),
  description text,
  price       numeric(12,2) not null default 0 check (price >= 0),
  quantity    integer     not null default 0 check (quantity >= 0),
  active      boolean     not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Busca por nome/descricao sem diferenciar maiuscula de minuscula.
create index if not exists products_name_idx on public.products (lower(name));
create index if not exists products_created_at_idx on public.products (created_at desc);

-- Mantem updated_at correto sem o backend precisar enviar o campo.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

-- RLS ligada: ninguem acessa a tabela com a anon key.
-- A API usa a service_role key, que ignora RLS por design.
alter table public.products enable row level security;

-- Se um dia o React for falar direto com o Supabase (sem a API),
-- descomente a policy abaixo para liberar leitura a usuarios logados:
-- create policy "produtos: leitura para autenticados"
--   on public.products for select
--   to authenticated
--   using (true);
