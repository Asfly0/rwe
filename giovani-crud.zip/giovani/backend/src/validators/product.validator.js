import { AppError } from '../middlewares/errorHandler.js';

/**
 * Validacao escrita a mao (sem dependencia extra).
 * Retorna apenas os campos conhecidos: o cliente nao consegue
 * injetar colunas que nao existem na tabela.
 */
function parseFields(body, { partial }) {
  const errors = {};
  const data = {};

  const has = (key) => Object.prototype.hasOwnProperty.call(body ?? {}, key);

  // name: string obrigatoria
  if (has('name') || !partial) {
    const name = typeof body?.name === 'string' ? body.name.trim() : '';
    if (name.length < 2) {
      errors.name = 'Informe um nome com pelo menos 2 caracteres.';
    } else if (name.length > 120) {
      errors.name = 'O nome deve ter no maximo 120 caracteres.';
    } else {
      data.name = name;
    }
  }

  // description: string opcional
  if (has('description')) {
    const description = body.description == null ? null : String(body.description).trim();
    if (description && description.length > 500) {
      errors.description = 'A descricao deve ter no maximo 500 caracteres.';
    } else {
      data.description = description || null;
    }
  } else if (!partial) {
    data.description = null;
  }

  // price: numero >= 0
  if (has('price') || !partial) {
    const price = Number(body?.price);
    if (!Number.isFinite(price) || price < 0) {
      errors.price = 'Informe um preco numerico maior ou igual a zero.';
    } else {
      data.price = Math.round(price * 100) / 100;
    }
  }

  // quantity: inteiro >= 0
  if (has('quantity') || !partial) {
    const quantity = Number(body?.quantity ?? 0);
    if (!Number.isInteger(quantity) || quantity < 0) {
      errors.quantity = 'Informe uma quantidade inteira maior ou igual a zero.';
    } else {
      data.quantity = quantity;
    }
  }

  // active: booleano
  if (has('active')) {
    if (typeof body.active !== 'boolean') {
      errors.active = 'O campo active deve ser true ou false.';
    } else {
      data.active = body.active;
    }
  } else if (!partial) {
    data.active = true;
  }

  if (Object.keys(errors).length > 0) {
    throw new AppError('Dados invalidos.', 422, errors);
  }

  if (partial && Object.keys(data).length === 0) {
    throw new AppError('Envie pelo menos um campo para atualizar.', 422);
  }

  return data;
}

export const validateCreate = (body) => parseFields(body, { partial: false });
export const validateUpdate = (body) => parseFields(body, { partial: true });

/**
 * Parametros de listagem (busca + paginacao).
 */
export function validateListQuery(query = {}) {
  const page = Math.max(1, Number.parseInt(query.page ?? '1', 10) || 1);
  const rawLimit = Number.parseInt(query.limit ?? '10', 10) || 10;
  const limit = Math.min(100, Math.max(1, rawLimit));
  const search = typeof query.search === 'string' ? query.search.trim() : '';

  return { page, limit, search };
}
