import 'dotenv/config';

/**
 * Centraliza a leitura de variaveis de ambiente.
 * Nenhum outro arquivo le process.env direto, o que facilita trocar
 * de ambiente (local, staging, producao) sem cacar strings pelo codigo.
 */
export const env = {
  port: Number(process.env.PORT ?? 3001),
  corsOrigin: process.env.CORS_ORIGIN ?? 'http://localhost:5173',

  // "memory" | "supabase"
  dbDriver: (process.env.DB_DRIVER ?? 'memory').toLowerCase(),

  supabase: {
    url: process.env.SUPABASE_URL ?? '',
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY ?? '',
    table: process.env.SUPABASE_TABLE ?? 'products',
  },
};
