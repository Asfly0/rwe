import { productsRepository as repo } from '../data/index.js';
import { AppError, asyncHandler } from '../middlewares/errorHandler.js';
import {
  validateCreate,
  validateUpdate,
  validateListQuery,
} from '../validators/product.validator.js';

/**
 * O controller nao sabe se os dados vem da memoria ou do Supabase.
 * Ele so conhece a interface do repositorio.
 */

// GET /api/products?page=1&limit=10&search=texto
export const list = asyncHandler(async (req, res) => {
  const { page, limit, search } = validateListQuery(req.query);
  const { items, total } = await repo.list({ page, limit, search });

  res.json({
    data: items,
    meta: { page, limit, total, totalPages: Math.max(1, Math.ceil(total / limit)) },
  });
});

// GET /api/products/:id
export const getById = asyncHandler(async (req, res) => {
  const row = await repo.findById(req.params.id);
  if (!row) throw new AppError('Produto nao encontrado.', 404);

  res.json({ data: row });
});

// POST /api/products
export const create = asyncHandler(async (req, res) => {
  const payload = validateCreate(req.body);
  const row = await repo.create(payload);

  res.status(201).json({ data: row });
});

// PUT/PATCH /api/products/:id
export const update = asyncHandler(async (req, res) => {
  const payload = validateUpdate(req.body);
  const row = await repo.update(req.params.id, payload);
  if (!row) throw new AppError('Produto nao encontrado.', 404);

  res.json({ data: row });
});

// DELETE /api/products/:id
export const remove = asyncHandler(async (req, res) => {
  const deleted = await repo.remove(req.params.id);
  if (!deleted) throw new AppError('Produto nao encontrado.', 404);

  res.status(204).send();
});
