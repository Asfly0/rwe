import { Router } from 'express';
import { productsRouter } from './products.routes.js';
import { productsRepository } from '../data/index.js';

export const router = Router();

// Util para checar de onde a API esta lendo os dados agora.
router.get('/health', (req, res) => {
  res.json({ status: 'ok', driver: productsRepository.driver });
});

router.use('/products', productsRouter);
