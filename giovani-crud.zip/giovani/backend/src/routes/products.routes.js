import { Router } from 'express';
import * as controller from '../controllers/products.controller.js';

export const productsRouter = Router();

productsRouter
  .route('/')
  .get(controller.list)
  .post(controller.create);

productsRouter
  .route('/:id')
  .get(controller.getById)
  .put(controller.update)
  .patch(controller.update)
  .delete(controller.remove);
