import { randomUUID } from 'node:crypto';

/**
 * Repositorio em memoria.
 * Serve para desenvolver e testar a API sem banco nenhum.
 * Os dados somem quando o processo reinicia.
 *
 * Usa UUID como id (mesmo formato do Supabase), entao o frontend
 * nao precisa mudar nada quando voce trocar o driver.
 */
const seed = () => [
  {
    id: randomUUID(),
    name: 'Teclado mecanico',
    description: 'Switch marrom, layout ABNT2',
    price: 349.9,
    quantity: 12,
    active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: randomUUID(),
    name: 'Monitor 27"',
    description: 'IPS, 144 Hz',
    price: 1899,
    quantity: 4,
    active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
];

export function createMemoryRepository() {
  let rows = seed();

  return {
    driver: 'memory',

    async list({ page, limit, search }) {
      let items = rows;

      if (search) {
        const term = search.toLowerCase();
        items = items.filter(
          (row) =>
            row.name.toLowerCase().includes(term) ||
            (row.description ?? '').toLowerCase().includes(term),
        );
      }

      items = [...items].sort((a, b) => b.created_at.localeCompare(a.created_at));

      const total = items.length;
      const start = (page - 1) * limit;

      return { items: items.slice(start, start + limit), total };
    },

    async findById(id) {
      return rows.find((row) => row.id === id) ?? null;
    },

    async create(data) {
      const now = new Date().toISOString();
      const row = { id: randomUUID(), ...data, created_at: now, updated_at: now };
      rows.push(row);
      return row;
    },

    async update(id, data) {
      const index = rows.findIndex((row) => row.id === id);
      if (index === -1) return null;

      rows[index] = { ...rows[index], ...data, updated_at: new Date().toISOString() };
      return rows[index];
    },

    async remove(id) {
      const index = rows.findIndex((row) => row.id === id);
      if (index === -1) return false;

      rows.splice(index, 1);
      return true;
    },
  };
}
