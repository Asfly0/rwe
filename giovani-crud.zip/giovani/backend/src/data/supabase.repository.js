import { createClient } from '@supabase/supabase-js';
import { AppError } from '../middlewares/errorHandler.js';
import { env } from '../config/env.js';

/**
 * Repositorio Supabase (PostgREST).
 * Expoe exatamente a mesma interface do repositorio em memoria,
 * entao controllers, rotas e frontend nao mudam uma linha.
 *
 * A service_role key ignora RLS de proposito: quem autoriza as
 * operacoes e esta API, nao o banco. Por isso ela fica so aqui.
 */
export function createSupabaseRepository() {
  const { url, serviceRoleKey, table } = env.supabase;

  if (!url || !serviceRoleKey) {
    throw new Error(
      'DB_DRIVER=supabase exige SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY no .env',
    );
  }

  const client = createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const from = () => client.from(table);

  // Traduz erro do Postgres para erro HTTP da nossa API.
  const fail = (error) => {
    switch (error.code) {
      case '23505': // unique_violation
        throw new AppError('Ja existe um registro com esses dados.', 409);
      case '23503': // foreign_key_violation
        throw new AppError('Registro referenciado nao existe.', 409);
      case '23514': // check_violation
      case '23502': // not_null_violation
        throw new AppError('Valor fora do permitido pela tabela.', 422);
      case '22P02': // invalid_text_representation (ex.: uuid malformado)
        throw new AppError('Identificador invalido.', 400);
      case '42P01': // undefined_table
        throw new AppError(
          `Tabela "${table}" nao existe no Supabase. Rode supabase/schema.sql.`,
          500,
        );
      default:
        throw new AppError(error.message, 500);
    }
  };

  return {
    driver: 'supabase',

    async list({ page, limit, search }) {
      const start = (page - 1) * limit;

      let query = from()
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(start, start + limit - 1);

      if (search) {
        // ilike = busca sem diferenciar maiuscula/minuscula
        query = query.or(`name.ilike.%${search}%,description.ilike.%${search}%`);
      }

      const { data, error, count } = await query;
      if (error) fail(error);

      return { items: data ?? [], total: count ?? 0 };
    },

    async findById(id) {
      const { data, error } = await from().select('*').eq('id', id).maybeSingle();
      if (error) fail(error);
      return data ?? null;
    },

    async create(payload) {
      const { data, error } = await from().insert(payload).select().single();
      if (error) fail(error);
      return data;
    },

    async update(id, payload) {
      const { data, error } = await from()
        .update(payload)
        .eq('id', id)
        .select()
        .maybeSingle();
      if (error) fail(error);
      return data ?? null;
    },

    async remove(id) {
      const { data, error } = await from().delete().eq('id', id).select('id').maybeSingle();
      if (error) fail(error);
      return Boolean(data);
    },
  };
}
