import { env } from '../config/env.js';
import { createMemoryRepository } from './memory.repository.js';
import { createSupabaseRepository } from './supabase.repository.js';

/**
 * Unico ponto do codigo que decide onde os dados moram.
 * Para migrar para o Supabase: DB_DRIVER=supabase no .env. Nada mais.
 *
 * Interface que todo repositorio precisa cumprir:
 *   list({ page, limit, search }) -> { items, total }
 *   findById(id)                  -> row | null
 *   create(data)                  -> row
 *   update(id, data)              -> row | null
 *   remove(id)                    -> boolean
 */
const drivers = {
  memory: createMemoryRepository,
  supabase: createSupabaseRepository,
};

const factory = drivers[env.dbDriver];

if (!factory) {
  throw new Error(
    `DB_DRIVER invalido: "${env.dbDriver}". Use um destes: ${Object.keys(drivers).join(', ')}`,
  );
}

export const productsRepository = factory();
