import { createApp } from './app.js';
import { env } from './config/env.js';
import { productsRepository } from './data/index.js';

const app = createApp();

app.listen(env.port, () => {
  console.log(`API rodando em http://localhost:${env.port}/api`);
  console.log(`Driver de dados: ${productsRepository.driver}`);
});
