/**
 * Erro de aplicacao com status HTTP, para o handler saber o que responder.
 */
export class AppError extends Error {
  constructor(message, status = 400, details = null) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

export function notFoundHandler(req, res) {
  res.status(404).json({ error: `Rota nao encontrada: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars -- o 4o parametro e obrigatorio no Express
export function errorHandler(err, req, res, next) {
  const status = err.status ?? 500;

  if (status >= 500) {
    console.error('[erro]', err);
  }

  res.status(status).json({
    error: status >= 500 ? 'Erro interno no servidor' : err.message,
    ...(err.details ? { details: err.details } : {}),
  });
}

/**
 * Evita try/catch repetido em todo controller async.
 */
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);
