import { useCallback, useEffect, useState } from 'react';
import { productsApi } from '../api/client.js';

const EMPTY_META = { page: 1, limit: 10, total: 0, totalPages: 1 };

/**
 * Concentra o estado do CRUD: lista, carregamento, erro, busca e paginacao.
 * Os componentes ficam so com a renderizacao.
 */
export function useProducts({ limit = 10 } = {}) {
  const [items, setItems] = useState([]);
  const [meta, setMeta] = useState(EMPTY_META);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchPage = useCallback(
    async (signal) => {
      setLoading(true);
      setError(null);

      try {
        const response = await productsApi.list({ page, limit, search }, signal);
        setItems(response.data);
        setMeta(response.meta);
      } catch (err) {
        if (err.name !== 'AbortError') setError(err.message);
      } finally {
        if (!signal?.aborted) setLoading(false);
      }
    },
    [page, limit, search],
  );

  // Busca com debounce: evita uma requisicao por tecla digitada.
  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(() => fetchPage(controller.signal), search ? 350 : 0);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [fetchPage, search]);

  const reload = useCallback(() => fetchPage(), [fetchPage]);

  const createProduct = useCallback(
    async (data) => {
      await productsApi.create(data);
      // Volta para a primeira pagina: o registro novo aparece no topo.
      if (page !== 1) setPage(1);
      else await reload();
    },
    [page, reload],
  );

  const updateProduct = useCallback(
    async (id, data) => {
      await productsApi.update(id, data);
      await reload();
    },
    [reload],
  );

  const removeProduct = useCallback(
    async (id) => {
      await productsApi.remove(id);
      // Se era o ultimo item da pagina, recua uma pagina.
      if (items.length === 1 && page > 1) setPage((current) => current - 1);
      else await reload();
    },
    [items.length, page, reload],
  );

  const changeSearch = useCallback((value) => {
    setSearch(value);
    setPage(1);
  }, []);

  return {
    items,
    meta,
    page,
    search,
    loading,
    error,
    setPage,
    changeSearch,
    reload,
    createProduct,
    updateProduct,
    removeProduct,
  };
}
