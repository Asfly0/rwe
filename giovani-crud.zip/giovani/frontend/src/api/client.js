/**
 * Unico lugar do frontend que fala HTTP.
 * Se a API mudar de endereco (ou de formato de erro), muda so aqui.
 */
const BASE_URL = import.meta.env.VITE_API_URL || '/api';

async function request(path, { method = 'GET', body, signal } = {}) {
  const response = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal,
  });

  if (response.status === 204) return null;

  const payload = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(payload?.error ?? `Falha na requisicao (${response.status})`);
    error.status = response.status;
    // Erros de validacao vem por campo: { name: "...", price: "..." }
    error.details = payload?.details ?? null;
    throw error;
  }

  return payload;
}

export const productsApi = {
  list: ({ page = 1, limit = 10, search = '' } = {}, signal) => {
    const params = new URLSearchParams({ page, limit });
    if (search) params.set('search', search);

    return request(`/products?${params}`, { signal });
  },

  create: (data) => request('/products', { method: 'POST', body: data }),

  update: (id, data) => request(`/products/${id}`, { method: 'PUT', body: data }),

  remove: (id) => request(`/products/${id}`, { method: 'DELETE' }),
};
