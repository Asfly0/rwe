import { useState } from 'react';
import { useProducts } from './hooks/useProducts.js';
import { ProductForm } from './components/ProductForm.jsx';
import { ProductTable } from './components/ProductTable.jsx';
import { Pagination } from './components/Pagination.jsx';

export default function App() {
  const {
    items,
    meta,
    page,
    search,
    loading,
    error,
    setPage,
    changeSearch,
    createProduct,
    updateProduct,
    removeProduct,
  } = useProducts({ limit: 10 });

  const [editing, setEditing] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [listError, setListError] = useState(null);

  const handleSubmit = async (data) => {
    if (editing) {
      await updateProduct(editing.id, data);
      setEditing(null);
    } else {
      await createProduct(data);
    }
  };

  const handleDelete = async (product) => {
    if (!window.confirm(`Excluir "${product.name}"?`)) return;

    setDeletingId(product.id);
    setListError(null);

    try {
      await removeProduct(product.id);
      if (editing?.id === product.id) setEditing(null);
    } catch (err) {
      setListError(err.message);
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <main className="container">
      <header className="page-header">
        <h1>Produtos</h1>
        <p className="muted">CRUD em React consumindo API Node + Express.</p>
      </header>

      <ProductForm editing={editing} onSubmit={handleSubmit} onCancel={() => setEditing(null)} />

      <section className="card">
        <div className="list-header">
          <h2>Lista</h2>
          <input
            type="search"
            value={search}
            onChange={(event) => changeSearch(event.target.value)}
            placeholder="Buscar por nome ou descricao"
            aria-label="Buscar produtos"
          />
        </div>

        {(error || listError) && <p className="error banner">{error ?? listError}</p>}

        <ProductTable
          items={items}
          loading={loading}
          deletingId={deletingId}
          onEdit={setEditing}
          onDelete={handleDelete}
        />

        <Pagination
          page={page}
          totalPages={meta.totalPages}
          total={meta.total}
          onChange={setPage}
        />
      </section>
    </main>
  );
}
