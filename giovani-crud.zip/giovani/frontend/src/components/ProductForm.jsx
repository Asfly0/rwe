import { useEffect, useState } from 'react';

const EMPTY = { name: '', description: '', price: '', quantity: '', active: true };

const toFormState = (product) =>
  product
    ? {
        name: product.name ?? '',
        description: product.description ?? '',
        price: String(product.price ?? ''),
        quantity: String(product.quantity ?? ''),
        active: Boolean(product.active),
      }
    : EMPTY;

/**
 * Serve para criar e para editar: quando recebe `editing`, vira formulario de edicao.
 * Os erros por campo vem do backend (error.details), nao sao duplicados aqui.
 */
export function ProductForm({ editing, onSubmit, onCancel }) {
  const [form, setForm] = useState(() => toFormState(editing));
  const [fieldErrors, setFieldErrors] = useState({});
  const [message, setMessage] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm(toFormState(editing));
    setFieldErrors({});
    setMessage(null);
  }, [editing]);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setFieldErrors({});
    setMessage(null);

    try {
      await onSubmit({
        name: form.name,
        description: form.description,
        price: form.price === '' ? 0 : Number(form.price),
        quantity: form.quantity === '' ? 0 : Number(form.quantity),
        active: form.active,
      });

      if (!editing) setForm(EMPTY);
    } catch (error) {
      setFieldErrors(error.details ?? {});
      setMessage(error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <form className="card form" onSubmit={handleSubmit} noValidate>
      <h2>{editing ? 'Editar produto' : 'Novo produto'}</h2>

      <label className="field">
        <span>Nome</span>
        <input name="name" value={form.name} onChange={handleChange} placeholder="Teclado mecanico" />
        {fieldErrors.name && <small className="error">{fieldErrors.name}</small>}
      </label>

      <label className="field">
        <span>Descricao</span>
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          rows={2}
          placeholder="Opcional"
        />
        {fieldErrors.description && <small className="error">{fieldErrors.description}</small>}
      </label>

      <div className="row">
        <label className="field">
          <span>Preco (R$)</span>
          <input name="price" value={form.price} onChange={handleChange} inputMode="decimal" placeholder="0,00" />
          {fieldErrors.price && <small className="error">{fieldErrors.price}</small>}
        </label>

        <label className="field">
          <span>Quantidade</span>
          <input name="quantity" value={form.quantity} onChange={handleChange} inputMode="numeric" placeholder="0" />
          {fieldErrors.quantity && <small className="error">{fieldErrors.quantity}</small>}
        </label>
      </div>

      <label className="field checkbox">
        <input type="checkbox" name="active" checked={form.active} onChange={handleChange} />
        <span>Produto ativo</span>
      </label>

      {message && <p className="error banner">{message}</p>}

      <div className="actions">
        <button type="submit" className="primary" disabled={saving}>
          {saving ? 'Salvando...' : editing ? 'Salvar alteracoes' : 'Cadastrar'}
        </button>

        {editing && (
          <button type="button" onClick={onCancel} disabled={saving}>
            Cancelar
          </button>
        )}
      </div>
    </form>
  );
}
