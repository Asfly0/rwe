const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

export function ProductTable({ items, loading, onEdit, onDelete, deletingId }) {
  if (loading) {
    return <p className="muted">Carregando produtos...</p>;
  }

  if (items.length === 0) {
    return <p className="muted">Nenhum produto encontrado.</p>;
  }

  return (
    <div className="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Nome</th>
            <th className="num">Preco</th>
            <th className="num">Qtd.</th>
            <th>Status</th>
            <th aria-label="Acoes" />
          </tr>
        </thead>
        <tbody>
          {items.map((product) => (
            <tr key={product.id}>
              <td>
                <strong>{product.name}</strong>
                {product.description && <small className="muted">{product.description}</small>}
              </td>
              <td className="num">{money.format(product.price)}</td>
              <td className="num">{product.quantity}</td>
              <td>
                <span className={product.active ? 'badge on' : 'badge off'}>
                  {product.active ? 'Ativo' : 'Inativo'}
                </span>
              </td>
              <td className="num">
                <button type="button" onClick={() => onEdit(product)}>
                  Editar
                </button>
                <button
                  type="button"
                  className="danger"
                  onClick={() => onDelete(product)}
                  disabled={deletingId === product.id}
                >
                  {deletingId === product.id ? '...' : 'Excluir'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
