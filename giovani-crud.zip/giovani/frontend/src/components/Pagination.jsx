export function Pagination({ page, totalPages, total, onChange }) {
  if (total === 0) return null;

  return (
    <div className="pagination">
      <button type="button" onClick={() => onChange(page - 1)} disabled={page <= 1}>
        Anterior
      </button>

      <span className="muted">
        Pagina {page} de {totalPages} &middot; {total} registro{total === 1 ? '' : 's'}
      </span>

      <button type="button" onClick={() => onChange(page + 1)} disabled={page >= totalPages}>
        Proxima
      </button>
    </div>
  );
}
